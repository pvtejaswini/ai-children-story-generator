// StoryNest AI — lightweight UI behavior (no animation libraries)

document.addEventListener("DOMContentLoaded", () => {
  // Mobile nav toggle
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      links.classList.toggle("nav-links-open");
    });
  }

  // Thin out decorative elements on low-power / small devices so animation
  // stays smooth (in addition to the CSS max-width rule for .deco-thin).
  const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const isSmall = window.innerWidth < 640;
  if (prefersReduced) {
    document.querySelectorAll(".deco, .story-bg [class*='motif-']").forEach(el => {
      el.style.animation = "none";
    });
  } else if (isSmall) {
    // remove every other decorative element beyond a sane cap
    const decos = document.querySelectorAll(".bg-layer .deco, .story-bg [class*='motif-']");
    decos.forEach((el, i) => {
      if (i % 2 === 1) el.style.display = "none";
    });
  }
});
